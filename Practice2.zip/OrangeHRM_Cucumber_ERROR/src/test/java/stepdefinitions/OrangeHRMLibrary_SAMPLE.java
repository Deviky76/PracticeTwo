package stepdefinitions;
/*package stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class OrangeHRMLibrary 
{

	@Given("i open browser with url") 
	public static void launchApp()
	{
		
		// code
		
	}
	
	@Then("i should see login page")
	public void isLoginPageDisplayed()
	{
		
		// code
	}
	
	
}
*/

