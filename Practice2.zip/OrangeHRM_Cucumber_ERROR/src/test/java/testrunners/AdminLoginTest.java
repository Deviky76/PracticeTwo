package testrunners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


//this java class run with RunWith Junit as a Cucumber class
// To run the Java class as a Cucumber class using Juint

@RunWith(Cucumber.class)
@CucumberOptions(features="featurefiles/adminlogin.feature",glue="stepdefinitions",
dryRun=false,tags=("@tag1,@tag2"),plugin={"com.cucumber.listener.ExtentCucumberFormatter:reports/loginresult.html"})
public class AdminLoginTest
{

}
