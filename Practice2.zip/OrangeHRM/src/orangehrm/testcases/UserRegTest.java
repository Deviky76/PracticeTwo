package orangehrm.testcases;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import orangehrm.library.AdminModuleUtils;
import orangehrm.library.User;

public class UserRegTest extends AdminModuleUtils
{

	@Parameters({"role","empname","uid","pwd"})
	@Test
	public void checkUserReg(String role, String empname, String uid, String pwd) throws InterruptedException
	{
	
		User us = new User();
		boolean res = us.adduser(role, empname, uid, pwd);
		Assert.assertTrue(res);
		
				
		
	}
	
}
