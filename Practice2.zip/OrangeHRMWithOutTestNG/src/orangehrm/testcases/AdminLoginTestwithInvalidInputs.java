package orangehrm.testcases;

import orangehrm.library.LoginPage;
import utils.AppUtils;

public class AdminLoginTestwithInvalidInputs 
{
	public static void main(String[] args) 
	{
	
		AppUtils.launchApp("http://orangehrm.qedgetech.com");
		
		LoginPage lp = new LoginPage();
		lp.login("min", "edge");

		
		boolean res = lp.isErrMsgDisplayed();
		
		if(res)
		{
			System.out.println("System displayed expected Error Message, Testcase Pass");
			
		}else
		{
			System.out.println("System not displayed expected Error Message, Testcase Fail");
			
		}
		
		AppUtils.closeApp();
	}
}
