package orangehrm.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import orangehrm.testcases.AdminLoginTest;

public class LoginPage 
{

	//Define Elements
	
	// selenium provide an Annotation FindBy() we can specify the locators require to identify this elements
	@FindBy(id="txtUsername")			
	WebElement uid_element;    // Declaring the variable of type WebElement
	
	@FindBy(id="txtPassword")
	WebElement pwd_element;
	
	@FindBy(xpath="//*[@value='LOGIN']")
	WebElement login_element;
	
	@FindBy(linkText="Admin")
	WebElement admin_link;
	
	@FindBy(partialLinkText="Welcome")
	WebElement welcome_link;
	
	@FindBy(linkText="Logout")
	WebElement logout;
	
	
	
	//Define Methods
	
	public void login(String uid, String pwd)
	{
		
		//Calling Functions
		
		uid_element.sendKeys(uid);
		pwd_element.sendKeys(pwd);
		login_element.click();
		
	}

	public boolean isAdminModuleDisplayed()
	{
		if(admin_link.isDisplayed())
		{
			return true;
		} else
		{
			return false;
		}
	}
	
	public void logout()
	{
		
		welcome_link.click();
		logout.click();
	}
	

}
